# Signaling Server

node.js server for webrtc

 npm install
            will install all required packages for it to work.

node server.js
        will run the server.          